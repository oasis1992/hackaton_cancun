<?php
class AdminController extends Controller
{
	/**
	 * Declares the behaviors.
	 * @return array the behaviors
	 */

	//$this->layout='login';

	public function actionIndex(){
		$this->redirect(array('/user/login'));
	}
}
