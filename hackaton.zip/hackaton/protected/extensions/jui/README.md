CJuiDateTimePicker
==================

CJuiDateTimePicker adds timing to the standard zii.widgets.jui.CJuiDatePicke